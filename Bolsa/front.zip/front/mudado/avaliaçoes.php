<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/avaliaçoes.css">

    <style>
         body {
            font-family: Arial, sans-serif;
            background-color: #e5e5e5;
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="row m-2 bg-secondary rounded-3 bg-white">
            <div class="col-12 text-center">
                <p>Raissa Felisberto</p>
            </div>
            <div class="col-12">
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit perspiciatis a quibusdam ipsa? Repellat suscipit voluptate modi ipsam, nulla repellendus, nobis maxime, tempora eligendi facere ea culpa dignissimos perferendis excepturi!</p>
            </div>
        </div>
    </div>
</body>
</html>