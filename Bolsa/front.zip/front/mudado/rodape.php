<footer class="footer">
        <div class="icons">
            <div class="fa-regular fa-calendar" id="calendar-btn"></div>
            <div class="fa-solid fa-house" id="home-btn"></div>
            <div class="fas fa-user" id="user-btn"> </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script src="scripts.js"></script>